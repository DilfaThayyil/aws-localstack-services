exports.handler = async (event) => {
    event.Records.forEach(record => {
        const srcBucket = record.s3.bucket.name;
        const srcKey = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));
        console.log(`Bucket: ${srcBucket}, Key: ${srcKey}`);
    });
    return {
        statusCode: 200,
        body: JSON.stringify('S3 event processed successfully!')
    };
};
